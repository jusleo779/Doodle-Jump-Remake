public class Random//give me random numbers for the different variables
{
    private int[][] vals; // row 0 is x-coordinates / row 1 is y-coordinates
    private int len;
    public Random(int length)
    {
        len = length;
        vals = new int [2][length];
    }
    
    public void randomizeX()//used for the bars to randomize the different horizontial placement
    {
        int valX = 0;
        int[] valXSave = new int[len];
        for(int i  = 0; i < valXSave.length; i++)//makes the variables in the array not null
        {
            valXSave[i] = 0;
        }
        int indx = 0;
        for(int c = 0; c < vals[0].length; c++)//makes it go throught the whole length of the first row of the array
        {
            valX= (int) ((Math.random() * 9) + 1);
            for(int i = 0; i < valXSave.length; i++)
            {
                while(valXSave[i] == valX)
                {
                    valX = (int) ((Math.random() * 9) + 1);
                }
            }
            valXSave[indx] = valX;
            indx++;
            vals[0][c] = valX * 40; //puts the x values into row 0
        }
    }
    
    public void randomizeY()//used for randomizing the vertical placements
    {
        int valY = 0;
        int[] valYSave = new int[len];
        for(int i  = 0; i < valYSave.length; i++)//makes the array not null
        {
            valYSave[i] = 0;
        }
        int indx = 0;
        for(int c = 0; c < vals[0].length; c++)//goes through the length of columns
        {
            valY= (int) ((Math.random() * 401) + 150);
            for(int i = 0; i < valYSave.length; i++)
            {
                while(valYSave[i] == valY)
                {
                    valY = (int) ((Math.random() * 401) + 150);
                }
            }
            valYSave[indx] = valY;
            indx++;
            vals[1][c] = valY;//put the height values into row 1
        }
    }
    
    public int[] randomItemSetup()//chooses random bars for the item to be placed on
    {
        int[] previousBarI = new int[len];
        int barI = 0;
        for(int i = 0; i < previousBarI.length; i++)
        {
            previousBarI[i] = 0;
        }
        for(int i = 0; i < previousBarI.length; i++)
        {
            barI = (int)(Math.random() * 30);
            for(int j = 0; j < previousBarI.length; j++)
            {
                while(barI == previousBarI[j])
                {
                    barI = (int)(Math.random() * 30);
                } 
            }
            previousBarI[i] = barI;
        }
        return previousBarI;
    }


    public int[][] getRandomNums()//allows the player to setup the bars with one method
    {
        randomizeX();
        randomizeY();
        return vals;
    }
    
    public int[][] getXYVals()//allows the other classes to use these saved variables
    {
        return vals;
    }

}