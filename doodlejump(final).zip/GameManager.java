import java.awt.*;
import java.awt.event.KeyEvent;
public class GameManager
{
    private Bar[] bars;
    private int[][] xY;
    private boolean move;
    private WeakBar[] weak;
    private Spring[] s;
    private Rocket[] r;
    private boolean rocketBarMovement;
    private static boolean youLose;
    public GameManager (Bar[] cs, int[][] xYVals, WeakBar[] b, Spring[] spring, Rocket[] rocket)//sets up the all the variables
    {
        bars = new Bar[cs.length];
        bars = cs;
        xY = new int[2][xYVals[0].length];
        xY = xYVals;
        move = false;
        weak = new WeakBar[b.length];
        weak = b;
        s = new Spring[spring.length];
        s = spring;
        r = new Rocket[rocket.length];
        r = rocket;
        rocketBarMovement = false;
        youLose = false;
    }

    public void background(Graphics gr)//keeps the background white so that there is no images being left behind after moving the player
    {
        gr.setColor(Color.WHITE);
        gr.fillRect(0, 0, 400, 600);
    }

    public void placeImages(Graphics g)//places the items and the bars
    {
        for(int i = 0; i < bars.length; i++)
        {
            bars[i].placeBars(g);
        }

        for(int i = 0; i < weak.length; i++)
        {
            weak[i].placeWBars(g);
        }

        for(int i = 0; i < s.length; i++)
        {
            s[i].placeSprings(g);
        }

        for(int i = 0; i < r.length; i++)
        {
            r[i].placeRockets(g);
        }
    }

    public void checker(Player p)//checks if the player has touched something / checks if the bars or items are below the specific height
    {
        barMoveCheck(p);//checks if its true that the bars should move
        checkFakeBar(p);
        checkFakeBarBelow();
        checkSpringBelow();
        checkRocketBelow();
    }

    public void screen(Graphics g, Player p)//screen the players sees
    {   
        background(g);//sets up the background
        placeImages(g);//places the bars on the screen
        p.barMove(p, bars, xY);//move the bars
        p.move(g);//moves the player
        checker(p);
        if(p.getY() >= 600)//lose screen for the player to see
        {
            youLose = true;
        }
    } 
    
    //checkers 
    public void checkFakeBar(Player p)
    {
        for(int i = 0; i < weak.length; i++)
        {
            weak[i].checkPlayer(p);
        }
    }

    public void checkFakeBarBelow()
    {
        for(int i = 0; i < weak.length; i++)
        {
            if(weak[i].getWeakBarHeight() >= 595)
                weak[i].moveBarsUp();
        }
    }

    public void checkSpringBelow()
    {
        for(int i = 0; i < s.length; i++)
        {
            if(s[i].getY() >= 595)
            {
                s[i].moveSpringUp(xY);
            }
        }
    }

    public void checkRocketBelow()
    {
        for(int i = 0; i < r.length; i++)
        {
            if(r[i].getY() >= 595)
            {
                r[i].moveRocketUp(xY);
            }
        }
    }

    public void barMoveCheck(Player p)
    {
        for(int i = 0; i < bars.length; i++)
        {
            if(p.getTouchRocket() && bars[i].getHeight() < p.getLowestBarHeight() && bars[i].getBounce() == true)//checks if the player is going down/ above bar / touching a rocket
            {
                rocketBarMovement = true;
            }
            else if(p.getOnSpring() && bars[i].getHeight() < p.getLowestBarHeight() && bars[i].getBounce() == true)//checks if the player is going down / above bar / touching a spring
            {
                move = true;
            }
            else if(bars[i].getHeight() < p.getLowestBarHeight() && bars[i].getBounce() == true) // checks if the player is touching a bar
            {
                move = true;
            }   

            if(rocketBarMovement) // moves the bar differently due to being a rocket
            {
                int barIsOn = p.getBarOnI();
                bars[barIsOn].barOnUpdateRocket(p, barIsOn, bars,  xY);
                xY = bars[barIsOn].getXYVals();
                p.updateXYVals(xY);
                if(p.getY() > 450)
                {
                    rocketBarMovement = false;
                }
            }
            else if (move == true)//moves the bars normally if it touches a spring or just a plain old bar
            {
                int barIsOn = p.getBarOnI();
                bars[barIsOn].barOnUpdate(p,barIsOn,bars, xY);
                xY = bars[barIsOn].getXYVals();
                p.updateXYVals(xY);//updates player xY Values
                weak[0].moveWBars(bars[barIsOn].getMoveCount(),weak);//moves the weakBars down
                s[0].moveSprings(bars[barIsOn].getMoveCount(), s);
                r[0].moveRocket(bars[barIsOn].getMoveCount(), r);
            }
        }
        for(int i = 0; i < bars.length; i++)
        {
            if(bars[i].getHeight() >= 590)//checks if a bar is below a specific height to reset the values and place it randomly above
            {
                bars[i].setBarY(bars[i].randomYNormal());
                bars[i].setBarX(bars[i].randomX());
                xY[0][i] = bars[i].getBarX();
                xY[1][i] = bars[i].getHeight();
                p.updateXYVals(xY);
                p.updateBar(bars);
                p.updateSpring(s);
                p.updateRocket(r);
                bars[i].bounceFalse(p); 
                move = false;
            }
        } 
    }
    
    //getters 

    public int[][] getXY()
    {
        return xY;
    }
    
    public boolean getLose()
    {
        return youLose;
    }
}