import java.awt.*;
public class WeakBar
{
    private int bX;
    private int height;

    public WeakBar(int x, int h)
    {
        bX = x;
        height = h;
    }

    public void placeWBars(Graphics gr)
    {
        gr.setColor(new Color(17,11,5));
        gr.fillRect(bX, height,30,5);
    } 
    
    
    public void checkPlayer(Player p)//check if the player is where the bar is at to reset the bar back up
    {
         if(p.getGrav() == true && (p.getX() >= bX && p.getX() <= (bX +  30)) && (p.getY() <= height && p.getY() >= height - 8))
         {
            setWeakBarHeight(-5);
            setWeakBarX((int)(Math.random() * 371));
         }
    }
    
    public void moveBarsUp()//sets the bar back up to the top randomly if it goes below the specified height
    {
        setWeakBarHeight(-(int)(Math.random() * 101));
        setWeakBarX((int)(Math.random() * 371));
    }
    
    public void moveWBars(int count, WeakBar[] wB)//move the bars down like the other bars
    {
        for(int i = 0; i < wB.length; i++)
        {
            wB[i].setWeakBarHeight(wB[i].height += count);
        }
    }
    
    //setters / getters
    
    public int getWeakBarHeight()
    {
        return height;
    }
    
    public void setWeakBarHeight(int y)
    {
        height =  y;
    }
    
    public void setWeakBarX(int x)
    {
        bX =  x;
    }
}