import java.awt.*;
public class Rocket
{
    private int x;
    private int y;
    private int[][] xYBar;
    public Rocket(int xCoord, int yCoord, int[][] xYBarCords)
    {
        x = xCoord;
        y = yCoord;
        xYBar = new int[2][xYBarCords[0].length];
        xYBar = xYBarCords;
    }

    public void placeRockets(Graphics g)
    {
        g.setColor(Color.RED);
        g.fillRect(x, y, 10,10);//puts the spring on top of the bar
    }

    public void moveRocket(int count, Rocket[] r)//moves the rocket down with the bar
    {
        for(int i = 0; i < r.length; i++)
        {
            r[i].setY(r[i].y += count);
        }
    }

    public void moveRocketUp(int[][] xY)//places the rockets when it goes below or have been used once
    {
        int count = 0;
        for(int i = 0; i < xY[0].length; i++)
        {
            if(xY[1][i] <= 150)
            {
                count++;
            }
        }
        int[] indxSave = new int[count];
        int indx = 0;
        for(int i = 0; i < xY[0].length; i++)
        {
            if(xY[1][i] <= 150)
            {
                indxSave[indx] = i;
                indx++;
            }
        }
        
        int random = (int)(Math.random() * count );
        
        x = xY[0][random] + (int)(Math.random() * 22);
        y = xY[1][random] - 10;
    }

    // getter / setters
    
    public void setY(int yVal)
    {
        y = yVal;
    }

    public void setX(int xVal)
    {
        x = xVal;
    }

    public int getX()
    {
        return x;
    }

    public int getY()
    {
        return y;
    }
}
