   public class Tester
{  
    public static void main (String[] args)
    {
        KeyboardInput test = new KeyboardInput();//runs everything
    }
} 