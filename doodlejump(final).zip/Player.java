import java.awt.*;
import java.awt.event.KeyEvent;
public class Player
{
    private int speedX;//speed of player moving left and right
    private Color color;//color of player
    private int x;//x coordinate of player
    private int y;//y coordinate of player
    private static boolean grav;//sets it so that i know if it should move down or up
    private static boolean bar;//it tells me if there is a bar below max height that it can bounce on
    private static boolean bounce;//know if you bounce up once so it can bounce on the bar on the new height

    private int lowestBarHeight;//set the lowest bar height
    private Bar[] bars;//save the values of all the bars
    private int[][] xYBarVals;//used to save the X coordinates/ Y coordinates of bar
    private int maxHeight;//sets the max height of where the player jumps
    private static int barOnI;//index for the bar its on so I know which bar to move first count how many times it moves down to move the bars the same number down
    private boolean aboveMaxHeight;//allows the player to jump when its higher than max height once
    
    private static boolean onSpring;//checks if player is on the spring
    private Spring[] s;//gets all the springs
    private boolean springMaxHeight;//checks if the max height has been hit by the player
    
    private static boolean touchRocket;//checks if player touched the rocket
    private Rocket[] r;//gets all the rocket (array allows me to add more rockets if I wanted) 
    private boolean rocketMaxHeight;//checks if its a the max height of the rocket
    
    public Player(int speed, Color c, int xCoord, int yCoord)
    {
        speedX = speed;//speed you set it to move at
        color = c; //color you want it to be
        x = xCoord; //the starting coordinate
        y = yCoord;//coordinate it starts at
        barOnI = 0;
        lowestBarHeight = 550;
        maxHeight = 450;
        bounce = false;
        grav = false;
        touchRocket = false;
        onSpring = false;
        springMaxHeight = false;
        rocketMaxHeight = false;
        aboveMaxHeight = false;
    }

    public void keyPressed(KeyEvent e)//not my work got it from oracle
    {     
        char key = e.getKeyChar();//not my work got it from oracle
        if(key == 'd' || key == 'D')
            speedX = 5;//speed 3 for school
        else if(key == 'a' || key == 'A')
            speedX = -5;   
    }

    public void keyReleased(KeyEvent e)//not my work got it from oracle
    {
        char key = e.getKeyChar();//not my work got it from oracle
        if(key == 'd' || key == 'D')
            speedX = 0;
        else if(key == 'a' || key == 'A')
            speedX = 0;
    }

    public void move(Graphics g)
    {
        x = x + speedX;//moves the player left and right
        loop();//loops the player if it goes to far left or right
        image(g);//image  of the player
    }

    public void barMove( Player p, Bar[] c, int[][] xY)
    {
        xYBarVals = xY;//update xY values of the bar
        checkBar();//checks if the bar value is true
        gravity(p, c);//player gravity for both bars/ off bar
    }

    public void image(Graphics g)//player character
    {
        g.setColor(color);
        g.fillOval(x, y, 10,10);
    }

    public int getBarOnI()//gets the index of the bar that player is on so it can allow the other classes to move the bars
    {
        return barOnI;
    }

    private void checkBar()
    {
        for(int i = 0; i < xYBarVals[0].length; i++)
        {
            if(xYBarVals[1][i] <= maxHeight)//checks if the player is above the bar so that it can bounce on it
            {
                bar = true;
            }
        }
    }

    private boolean isOnBars()//checks if the player is in the specific range of the bars (hitbox) so that it can jump on it
    {
        for(int i = 0; i < xYBarVals[0].length; i++)
        {
            if(y <= xYBarVals[1][i] && y >= xYBarVals[1][i] - 8)
            {
                if(x >= (xYBarVals[0][i] - 5) && x <=(xYBarVals[0][i] + 28))//if player is on the right value of x
                {
                    barOnI = i;
                    return true;
                }
            }
        }
        return false;
    }

    private boolean onSpringsChecker()//checks if its on a spring so it can boost the player up even more
    {
        for(int i = 0; i < s.length; i++)
        {
            if(y <= s[i].getY() && y >= s[i].getY() - 8)
            {
                if(x >= (s[i].getX() - 4) && x <=(s[i].getX() + 4))//if player is on the right value of x
                {
                    return true;
                }
            }
        }
        return false;
    }
    
    private boolean onRocketsChecker()//checks if its on a rocket so it can send the player above the maxHeight
    {
        for(int i = 0; i < r.length; i++)
        {
            if(y <= r[i].getY() && y >= r[i].getY() - 8)
            {
                if(x >= (r[i].getX() - 6) && x <=(r[i].getX() + 4))//if player is on the right value of x
                {
                    return true;
                }
            }
        }
        return false;
    }

    public void updateMultiple(Player p, Bar[] c) 
    {
        if(grav && onSpringsChecker())//checks if the player is going down and is on the spring
        {
            grav = false;//sets it so that the player knows that it should move up
            onSpring = true;//a variable that lets me set the new maxHeight for the player to jump up to
            bounce = true;//allows the player to interact with the bar
            bars[barOnI].bounceTrue(p);//let the bars know that it has been interacted with
        }
        else if(grav && onRocketsChecker())//checks if the player is going down and is on the rocket
        {
            grav = false;
            touchRocket = true;//let me set new maxHeight for the player to jump up to
            bounce = true;
            bars[barOnI].bounceTrue(p);
        }
        else if (grav && isOnBars()) //checks if the player is going down and is on the bar
        {
            grav = false;
            bounce = true;
            bars[barOnI].bounceTrue(p);
        }
    }

    public void gravity(Player p, Bar[]d)
    {
        if(bar == true)
        { 
            updateMultiple(p,d);
            if(onSpring)//changes the gravity to spring gravity 
            {
                setMaxHeight(300);
                gravityOnSprings();
            }
            else if(touchRocket)//change it so that player goes up higher with the rocket
            {
                setMaxHeight(0);
                RocketGravity();
            }
            else if(bounce)//allows the player to bounce on a bar above the original maxHeight
            {
                if(springMaxHeight)//allows the player to jump up once at the new height that is above the maxHeight (same with the rocket)
                {
                    setMaxHeight(y - 150);//spring max height when jumping on the new bar height
                    springMaxHeight = false;
                }
                else if(rocketMaxHeight)
                {
                    setMaxHeight(y - 50);//allows the player to jump on the bar once above at the after touching a bar above the original maxHeigh
                    rocketMaxHeight = false;
                    aboveMaxHeight = true;
                }
                else if(aboveMaxHeight)//allow the players to bounce on a bar above the maxHeight once
                {
                    setMaxHeight(y - 50);
                    aboveMaxHeight = false;
                }
                else 
                {
                    setMaxHeight(420);//normal max height on bars
                }
                gravityOnBars(); //allows the player to jump on the bars
            }
            else
            {
                playerGravity();//has the starting gravity and the gravity to make the player fall infinitely 
            }
        }
        //add else if statement in which sets the new height
        else
        {//moves the character up and down if there is no bar apart of the system
            playerGravity();
        }
    }
    
    
    public void RocketGravity()//gravity for the rocket
    {
        if(grav)
        {
            y += 5;
        }
        else
        {
            y -= 10;
            if(y <= 0)
            {
                grav = true;//tells the player that it should move down when gravity method is called
                touchRocket = false;//tells the player that it's not touching the rocket so that the gravity upwards is not the same
                bounce = false;//player not interacting with a bar anymore
                rocketMaxHeight = true;
            }
        }
    }

    public void gravityOnSprings()//gravity for the spring
    {
        if(grav)
        {
            y += 5;
        }
        else
        {
            y -= 10;
            if(y <= maxHeight)
            {
                grav = true;
                onSpring = false;
                bounce = false;
                springMaxHeight = true;
            }
        }
    }

    public void gravityOnBars()//gravity on the bars
    {    
        if(grav == false)//makes it so that it bounces up if its on top of the bar
        {
            if(y <= maxHeight)// max height
            {
                grav = true;
                bounce = false;//make it false so it doesn't bounce infinitely in the air
            }
            y -= 5;//moves up
        }
    }

    public void loop()//loops the player so that if it goes far enough off the screen (left or right) it will send them to the other side 
    {
        if(x > 410)
        {
            x = 0;
        }
        else if (x < -10)
        {
            x = 400;
        }
    }

    private void playerGravity()//starting gravity / makes player fall infintely if not interacting with bars
    {
        if(grav == true)   
        {//speed 1 at school
            y += 5; //moves down
        }   
        else if(y == 450)
        {
            grav = true;
        } 
        else
            y -= 5;//moves up  
    }
    
    // getters / setters / update Variables
    public int getX()
    {
        return x;
    }

    public int getY()
    {
        return y;
    }

    public void updateXYVals(int[][] xY)
    {
        xYBarVals = xY;
    }

    public void updateBar(Bar[] b)
    {
        bars = b;
    }
    
    public  void updateSpring(Spring[] sp)
    {
        s = sp;
    }
    
    public  void updateRocket(Rocket[] rocket)
    {
        r = rocket;
    }

    public boolean getGrav()
    {
        return grav;
    }
    
    public void setMaxHeight(int h)
    {
        maxHeight = h;
    }
    
    public void setSpring(Spring[] spring)
    {
        s = new Spring[spring.length];
        s = spring;
    }

    public void setRocket(Rocket[] rocket)
    {
        r = new Rocket[rocket.length];
        r = rocket;
    }
    
    public void setXYBarVals(int[][] s)
    {
        xYBarVals = new int [s.length][s[0].length];
        xYBarVals = s;
    }

    public void setBars(Bar[] b)
    {
        bars = new Bar[b.length];
        bars = b;
    }

    public boolean getBarVal()
    {
        return bar;
    }

    public boolean getBounce()
    {
        return bounce;
    }

    public int getLowestBarHeight()
    {
        return lowestBarHeight; 
    }    

    public boolean getOnSpring()
    {
        return onSpring;
    }
    
    public boolean getTouchRocket()
    {
        return touchRocket;
    }
}