import java.awt.*;
public class Bar
{
    private int bX;//bar horizontal coordinate
    private int height;//bar y coordinate 
    private boolean bounce;//variable to tell the bars to move & which bar its on
    private int[][] xY;//coordinates of the bar
    private static int moveCount;//tells my other bars how much they should move down 
    public Bar(int x, int h, boolean bnce, int[][] xYVals)
    {
        bX = x;//the horizontal placement
        height = h;//vertical placement
        bounce = bnce;//tells me whether or not the bar is being bounced on
        xY = new int[2][xYVals[0].length];//gives the xY values of the bar
        moveCount = 0;
    }

    public void placeBars(Graphics gr)//prints the bars on the screen
    {
        gr.setColor(new Color(150,75,0));
        gr.fillRect(bX, height,30,5);
    } 

    public void bounceTrue(Player p)//updates the bounce true 
    { 
        bounce = true; 
    }
    //cant do bounce = !bounce; bc it will break program due to not working how I want the program to work
    public void bounceFalse(Player p)//updates the bounce false
    { 
        bounce = false; 
    }

    public void barOnUpdateRocket(Player p, int indx, Bar[] bs, int[][] xYVals)//updates the bars when there is a rocket in use
    { 
        int count = 0;
        int barOn = bs[indx].getHeight();
        int len = 0;
        int count1 = 0;
        for(int i = 0; i < bs.length; i++)//gets the bars below the bar its on
        {
            if(bs[i].getHeight() > bs[indx].getHeight())
            {
                count++;
            }
        }

        for(int i = 0; i < bs.length; i++)//gets the length of the bars above the bar it just bounced on
        {
            if(bs[i].getHeight() < bs[indx].getHeight())
            {
                len++;
            }
        }
        int[] saveIndx = new int[len];
        int index = 0;
        for(int i = 0; i < bs.length; i++)//save the indexes of the bars that is above the bar it bounces on
        {
            if(bs[i].getHeight() < bs[indx].getHeight())
            {
                saveIndx[index] = i;
                index++;
            }
        }

        if(bounce)//check if the player has bounced
        {
            while(height != p.getLowestBarHeight())
            {
                barOn++;
                bs[indx].setBarY(barOn);
                count1++;
            }
            xYVals[1][indx] = bs[indx].getHeight();
        }

        for(int i = 0; i < saveIndx.length; i++)//moves the bars down that are still above the bar that the player bounced ong
        {
            int count2 = 0;
            while(count2 != count1)
            {
                barOn++;
                bs[i].setBarY(barOn);
                count2++;
            } 
        }
        barUpdateRocket(bs, indx, xYVals, len);
    }

    public void barUpdateRocket(Bar[] bs, int indx, int[][] xYVals, int range)//places the bars randomly spaced out so that it will give a path to the player to jump up
    { 
        for(int i = 0; i < bs.length; i++)
        {
            if(bs[i].getHeight() <= 550 && bs[i].getHeight() >= 550 - range)
            {
                i++;
            }
            else if( i < bs.length)
            {
                int counter = 0;
                int h = bs[i].getHeight();
                int valY = 0;
                valY = (int)((Math.random() * range + 1) + (450 - range));
                for(int j = 0; j < xY[0].length; j++)
                {
                    while(xYVals[1][j] - valY <= 100 && xYVals[1][j] - valY >= 10)
                    {
                        valY = (int)((Math.random() * range + 1) + (450 - range));
                    }
                }
                xYVals[1][i] = bs[i].getHeight();
            } 
        }

        xY = xYVals;
    } 

    public void barOnUpdate(Player p, int indx, Bar[] bs, int[][] xYVals)//update the bars normally when there isn't a rocket being used
    { 
        int count = 0;
        int barOn = bs[indx].getHeight();
        if(bounce)
        {
            while(height != p.getLowestBarHeight())
            {
                barOn++;
                bs[indx].setBarY(barOn);
                count++;
            }
            xYVals[1][indx] = bs[indx].getHeight();
        }
        moveCount = count;
        barUpdateRest(bs, indx, count, xYVals);
    } 

    public void barUpdateRest(Bar[] bs, int indx, int count,int[][] xYVals)//updates the bars normally 
    { 
        for(int i = 0; i < bs.length; i++)
        {
            int counter = 0;
            if(i == indx)
            {
                i++;
            }
            if(i < bs.length)
            {
                int h = bs[i].getHeight();
                while(counter != count)//moves the bars the same amount down as the one the player is jumping on
                {
                    h++;
                    bs[i].setBarY(h);
                    counter++;
                }
                xYVals[1][i] = bs[i].getHeight();
            }
        }
        xY = xYVals;
    } 
    
    // randomizers / setters / getters

    public int getMoveCount()
    {
        return moveCount;
    }

    public int randomX()//used to randomize the bar after going below a specific height
    {
        int valX = 0;
        valX = (int) ((Math.random() * 371));
        return valX;
    }

    public int randomYNormal()//sets it above the screen height so more bars can come down infinitly
    {
        int valY = 0;
        valY = (int)((Math.random() * 401) + 50);
        return valY;
    }

    public int getBarX()
    {
        return bX;
    }

    public void setBarX(int x)
    {
        bX = x;    
    }

    public void setBarY(int y)//used to update the values after moving down
    {
        height = y;    
    }

    public int[][] getXYVals()
    {
        return xY;
    }

    public int getHeight()
    {
        return height;
    }

    public boolean getBounce()
    {
        return bounce;
    }
}