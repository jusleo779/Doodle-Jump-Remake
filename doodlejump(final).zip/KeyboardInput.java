import javax.swing.*;  
import java.awt.*;     
import java.awt.event.KeyEvent;//movement
import java.awt.event.KeyListener;//movement
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Graphics;
import java.io.File;
import java.awt.image.BufferedImage;
import java.io.*;
import javax.imageio.ImageIO;
import java.io.IOException;
public class KeyboardInput extends JFrame implements KeyListener //not my code
{ 
    private Player p1;
    private GameManager gm;
    private Bar[] bars;
    private WeakBar[] wBar;
    private Random xYBarVals;
    private Random xYWeakBar; 
    private Spring[] sp;
    private int[][] vals;
    private Random xYSpring;
    private Random xYRocket;
    private Rocket[] r;
    private BufferedImage image;
    public KeyboardInput()
    {
        JFrame win;                
        Container contentPane;
        Graphics g;
        
        win = new JFrame("Doodle Jump");  
        win.setSize(400,620);//400 600 school computer
        win.setLocation(100,100);
        win.setVisible(true);
        contentPane = win.getContentPane();   
        g = contentPane.getGraphics();

        win.addKeyListener(this); //not my work
        p1 = new Player(0, Color.BLACK, 175, 540);
        barSetup();
        weakBarSetup();
        vals = xYBarVals.getXYVals();
        springSetup();
        rocketSetup();
        p1.setXYBarVals(vals);
        p1.setSpring(sp);
        p1.setRocket(r);
        gm = new GameManager(bars, vals, wBar, sp, r);
        while(true)
        {
            try {Thread.sleep(50);} catch (Exception e) {}  
            if(gm.getLose())
            {
                loseScreen(g);
            }
            else
            {
                gm.screen(g,p1);
            }
            repaint();//repaints the image 
        }
    }
    
    public void rocketSetup()
    {
        r = new Rocket[1];
        int indx = 0;
        xYRocket = new Random(r.length); 
        int[] randBar = xYRocket.randomItemSetup();
        for(int i = 0; i < r.length; i++)
        {
            int x = bars[(randBar[i])].getBarX();
            int y = bars[(randBar[i])].getHeight();
            int temp = (int)(Math.random() * 26);
            r[indx] = new Rocket(x + temp, y - 10, vals);
            indx++;
        }
    }
    
    public void loseScreen(Graphics g)
    {
        g.setColor(Color.BLACK);
        g.fillRect(0,0, 450,650);
        //got it from Logan {
        try{
            image = ImageIO.read(getClass().getResourceAsStream("GameOver.jpg"));
        }
        catch(IOException e)
        {
            
        }
        g.drawImage(image, 100,200, 200, 200,null);
        //}
    }
    
    public void springSetup()//setups the springs so that they are randomly placed on the bar 
    {
        sp = new Spring[3];
        int indx = 0;
        xYSpring = new Random(sp.length); 
        int[] randBarsIndx = xYSpring.randomItemSetup();
        for(int i = 0; i < sp.length; i++)
        {
            int x = bars[(randBarsIndx[i])].getBarX();
            int y = bars[(randBarsIndx[i])].getHeight();
            int temp = (int)(Math.random() * 26);
            sp[indx] = new Spring(x + temp, y - 5, vals);
            indx++;
        }
    }

    public void weakBarSetup()//places the bars randomly around the background 
    {
        wBar = new WeakBar[5];
        int indx = 0;
        xYWeakBar = new Random(wBar.length);
        int[][] xY = xYWeakBar.getRandomNums();
        for(int c = 0; c < xY[0].length; c++)
        {
            wBar[indx] = new WeakBar(xY[0][c], xY[1][c]);
            indx++;
        }
    }
    
    public void barSetup()//setups the bars the player can jump on
    {
        bars = new Bar[30];
        int indx = 0;
        xYBarVals = new Random(bars.length);
        int[][] xY = xYBarVals.getRandomNums();
        for(int c = 0; c < xY[0].length; c++)
        {
            bars[indx] = new Bar(xY[0][c], xY[1][c], false, xY);
            indx++;
        }
        p1.setBars(bars);
    }

    public void keyTyped(KeyEvent e)
    {
        //need it for interface but dont need it
    }

    public void keyPressed(KeyEvent e)//allows my player to move
    {
        p1.keyPressed(e);
    }

    public void keyReleased(KeyEvent e)//stops my player when the key was released
    { 
        p1.keyReleased(e);
    }

}