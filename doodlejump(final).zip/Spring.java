import java.awt.*;
public class Spring 
{
    private int x;
    private int y;
    private int[][] xYBar;    
    public Spring(int xCoord, int yCoord, int[][] xYBarCords)
    {
        x = xCoord;
        y = yCoord;
        xYBar = new int[2][xYBarCords[0].length];
        xYBar = xYBarCords;
    }

    public void placeSprings(Graphics g)
    {
        g.setColor(new Color(128,128,128));
        g.fillRect(x, y, 8,5);//puts the spring on top of the bar
    }

    public void moveSprings(int count, Spring[] s)//moves the springs down with the bar
    {
        for(int i = 0; i < s.length; i++)
        {
            s[i].setY(s[i].y += count);
        }
    }

    public void moveSpringUp(int[][] xY)//moves the springs up to random bars
    {
        int count = 0;
        for(int i = 0; i < xY[0].length; i++)
        {
            if(xY[1][i] <= 300)
            {
                count++;
            }
        }
        int[] indxSave = new int[count];
        int indx = 0;
        for(int i = 0; i < xY[0].length; i++)
        {
            if(xY[1][i] <= 300)
            {
                indxSave[indx] = i;
                indx++;
            }
        }
        
        int random = (int)(Math.random() * count );
        
        x = xY[0][random] + (int)(Math.random() * 22);
        y = xY[1][random] - 5;
    }
    
    // setters / getters

    public void setY(int yVal)
    {
        y = yVal;
    }

    public void setX(int xVal)
    {
        x = xVal;
    }

    public int getX()
    {
        return x;
    }

    public int getY()
    {
        return y;
    }
}